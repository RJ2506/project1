
from sqlite3 import connect
import connexion
from connexion import NoContent
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from base import Base
import yaml
import pymysql
import pymongo
import mysql.connector
import pandas as pd
from input import InputItem


# DB Config for MongoDB


myclient = pymongo.MongoClient("mongodb://172.30.0.6:27017/")
mydb = myclient["movie_db"]
movie_table = mydb["movie_table"]



with open("app_conf.yml", "r") as f:
    app_config = yaml.safe_load(f.read())

DB_ENGINE = create_engine(f'mysql+pymysql://{app_config["datastore"]["user"]}:{app_config["datastore"]["password"]}@{app_config["datastore"]["hostname"]}:{app_config["datastore"]["port"]}/{app_config["datastore"]["db"]}'
)

Base.metadata.bind = DB_ENGINE
DB_SESSION = sessionmaker(bind=DB_ENGINE)


def get_data():
    """get the data from the mysql database service"""
    session = DB_SESSION()
    readings = session.query(InputItem)
    result_list = []

    for reading in readings:
        result_list.append(reading.to_dict())
    
    stat_param(result_list)
    session.close()

    return '200'

def stat_param(data):
    """create the value of all the statistical parameter """
    
    movie_data = pd.DataFrame(data)
    
    # get the statistical parameter of movie name
   
    movieName = movie_data['movie_name']
    mapping_movie = []
    for movie in movieName:
        if movie not in mapping_movie:
            mapping_movie.append(movie)
   
    stats_dict = {}
    
    for i in range(len(mapping_movie)):
        pop_movie = (movie_data.loc[movie_data['movie_name'] == mapping_movie[i]])
       
        stats_dict[mapping_movie[i]] = pop_movie['movie_name'].count()
    
    
    popular_movie = max(stats_dict, key=stats_dict.get)
    print(popular_movie)
    
    
    #insert into mongo db
    toInsert = {'max_rating': str(movie_data['movie_rating'].max()), 'min_rating': str(movie_data['movie_rating'].min()), 'avg_rating': str(movie_data['movie_rating'].mean()) ,'popular_movie':popular_movie}
    print(toInsert)
    movie_table.insert_one(toInsert)
    

app = connexion.FlaskApp(__name__, specification_dir="")
app.add_api("analytics.yaml")

if __name__ == "__main__":
    app.run(port=8100)




