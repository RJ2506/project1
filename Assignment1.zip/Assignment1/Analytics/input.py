from sqlalchemy import Column, Integer, String, DateTime, Float
from base import Base

class InputItem(Base):
    """enter the input into the database"""

    __tablename__ = "movies"

    id = Column(Integer, primary_key=True)
    movie_name = Column(String(50), nullable=False)
    movie_genre = Column(String(20), nullable=False)
    production_company = Column(String(100), nullable=False)
    movie_rating = Column(Integer, nullable=False)

    def __init__(
        self,
        movie_name, movie_genre,production_company, movie_rating
    ):
        """Initialize the input of the data """
        self.movie_name = movie_name
        self.movie_genre = movie_genre
        self.production_company = production_company
        self.movie_rating = movie_rating

    def to_dict(self):
        """create a dictionary of thet input data"""
        dict = {}
        dict["id"] = self.id
        dict["movie_name"] = self.movie_name
        dict["movie_genre"] = self.movie_genre
        dict["production_company"] = self.production_company
        dict["movie_rating"] = self.movie_rating

        return dict