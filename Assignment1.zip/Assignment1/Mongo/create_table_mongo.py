import pymongo

myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["movie_db"]

# mongoDB needs at least one table and one value to create database
movie_table = mydb["movies"]
table_default = {'max_rating':"default_initialize", 'min_rating':"default_initialize", 'avg_rating':"default_initialize", 'popular_movie':"default_initialize"}
movie_table.insert_one(table_default)


dblist = myclient.list_database_names()

if "movie_db" in dblist:
  print("Database created")