const express = require("express");
const session = require("express-session");
const fetch = require("node-fetch");
const mysql = require("mysql");
const app = express();
const http = require("http").createServer(app);
app.use(
    session({
        secret: "secret",
        resave: true,
        saveUninitialized: true,
    })
);

//connect to the mysql
const con = mysql.createConnection({
    host: "172.30.0.3",
    user: "dbuser",
    password: "dbpassword",
    database: "data_db",
    port: 3306,
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set("view engine", "ejs");

http.listen(8080);
console.log("App running at http://localhost:8080/login");

app.get("/login", (req, res) => {
    res.render("./login.ejs");
});

app.get("/enter", (req, res) => {
    res.render("./login.ejs");
});

app.post("/login", (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    const settings = {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
        },
    };

    fetch(
            `http://172.30.0.4:8090/login?username=${username}&password=${password}`,
            settings
        )
        .then((response) => response.status)
        .then(async(status) => {
            if (status === 204) {
                res.render("home.ejs");
            }
        })

    .catch((err) => {
        console.log(err);
        response.render("login.ejs");
    });
});
app.post("/enter", (req, res) => {
    console.log(req.body);
    let movieName = req.body.movie_name;
    let movieGenre = req.body.movie_genre;
    let productionCompany = req.body.production_company;
    let movieRating = req.body.movie_rating;

    const sql_query = `insert into movies (movie_name,movie_genre, production_company, movie_rating) Values ("${movieName}", "${movieGenre}", "${productionCompany}", ${movieRating});`;
    con.query(sql_query, (err, result) => {
        if (err) throw err;
        console.log(result);
        console.log("Inserted values");
        res.render("home.ejs");
    });
});