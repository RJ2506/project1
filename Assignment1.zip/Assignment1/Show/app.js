const { info } = require("console");
const express = require("express");
const session = require("express-session");
const fetch = require("node-fetch");
const app = express();

const http = require("http").createServer(app);
app.use(
    session({
        secret: "secret",
        resave: true,
        saveUninitialized: true,
    })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set("view engine", "ejs");

const MongoClient = require("mongodb").MongoClient;
const url = "mongodb://172.30.0.6:27017/";

http.listen(8200);

app.get("/show", (req, res) => {
    res.render("./login.ejs");
});

app.get("/login", (req, res) => {
    res.render("./login.ejs");
});

app.post("/login", (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    const settings = {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
        },
    };
    fetch(
            `http://172.30.0.4:8090/login?username=${username}&password=${password}`,
            settings
        )
        .then((response) => response.status)
        .then(async(status) => {
            //call the analytics service to update the value in the mongodb
            const get = {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                },
            };

            fetch(`http://172.30.0.5:8100/analyze`, get)
                .then((response) => console.log(response.status))
                .catch((err) => console.log(err));
            console.log("success");
        })
        .then(() => {
            //retrieve the data from the mongodb
            MongoClient.connect(url, function(err, db) {
                if (err) throw err;
                const dbo = db.db("movie_db");
                dbo
                    .collection("movie_table")
                    .find({})
                    .sort({ $natural: -1 })
                    .limit(1)
                    .toArray((err, result) => {
                        if (err) throw err;

                        db.close();

                        if (result.length == 0) {
                            var items = {
                                body: "No movies in the database yet.",
                            };
                            res.render("empty", items);
                        } else {
                            console.log(result);
                            var items = {
                                body: result[0],
                                update: result[0],
                                body_length: info.length,
                                update_length: info.length,
                            };
                            res.render("show", items);
                        }
                    });
            });
        })

    .catch((err) => {
        console.log(err);
        response.render("login.ejs");
    });
});

console.log("App running at http://localhost:8200/show");