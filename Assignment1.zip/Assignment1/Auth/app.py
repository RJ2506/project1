import connexion
from connexion import NoContent
from authentication import Authenticate



def login_user(username, password):
    """Authenticates the user if its in the database"""
    # get the parameters from the login page
    print(username, password)
    user = Authenticate()

    res = user.check_credentials(username, password)
    print(res)
    return NoContent


app = connexion.FlaskApp(__name__, specification_dir="")
app.add_api("openapi.yaml", strict_validation=True, validate_responses=True)
if __name__ == "__main__":
    app.run(port=8090)
