CREATE DATABASE IF NOT EXISTS data_db;

USE data_db;

CREATE TABLE IF NOT EXISTS movies
          (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
           movie_name VARCHAR(50) NOT NULL,
           movie_genre VARCHAR(50) NOT NULL,
           production_company VARCHAR(100) NOT NULL,
           movie_rating INT NOT NULL);


        