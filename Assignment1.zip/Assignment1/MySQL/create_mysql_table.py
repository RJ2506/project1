import mysql.connector

db_conn = mysql.connector.connect(host="localhost", user="dbuser", 
password="dbpassword", database="data_db")

db_cursor = db_conn.cursor()

db_cursor.execute('''
    CREATE TABLE IF NOT EXISTS movies
    (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    movie_name VARCHAR(50) NOT NULL,
    movie_genre VARCHAR(50) NOT NULL,
    production_company VARCHAR(100) NOT NULL,
    movie_rating INT NOT NULL)
    ''')
db_conn.commit()
db_conn.close()
